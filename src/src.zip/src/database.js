const mongoose = require('mongoose');//Descarga mongoose

mongoose.connect('mongodb://127.0.0.1:27017/Jaime')//Conexion a base de datos
.then(()=>{
    console.log("mongo conectado")
})
.catch(()=>{
    console.log("mongo no conectado")
})
    