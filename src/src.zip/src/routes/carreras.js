const express = require('express');
const router = express.Router();
const Carrera = require('../models/carrera');



// Ruta para mostrar todas las carreras
router.get('/carreras', async (req, res) => {
  const carreras = await Carrera.find().lean();
  res.render('carreras/index', { carreras });
});

// Ruta para agregar una nueva carrera
router.get('/carreras/add', async (req, res) => {
  res.render('carreras/add');
});

router.post('/carreras/add', async (req, res) => {
  const { nombre, descripcion, departamento } = req.body;
  const errors = [];

  if (!nombre) {
    errors.push({ text: 'Por favor ingrese el nombre de la carrera' });
  }

  if (!descripcion) {
    errors.push({ text: 'Por favor ingrese la descripción de la carrera' });
  }

  if (!departamento) {
    errors.push({ text: 'Por favor ingrese el departamento de la carrera' });
  }

  if (errors.length > 0) {
    res.render('carreras/add', { errors, nombre, descripcion, departamento });
  } else {
    const newCarrera = new Carrera({ nombre, descripcion, departamento });
    await newCarrera.save();
    req.flash('success_msg', 'Carrera agregada exitosamente');
    res.redirect('/carreras');
  }
});

module.exports = router;
