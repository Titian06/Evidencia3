const express = require('express');
const router = express.Router();
const Alumno = require('../models/alumno');
const Carrera = require('../models/carrera');

// Ruta para mostrar el formulario de agregar alumno
router.get('/alumnos/add', async (req, res) => {
  try {
    const carreras = await Carrera.find().lean();
    res.render('alumnos/add', { carreras });
  } catch (error) {
    console.log(error);
  }
});

// Ruta para agregar un nuevo alumno
router.post('/alumnos/add', async (req, res) => {
  const { nombre, apellido,edad, carrera } = req.body;
  const errors = [];

  if (!nombre) {
    errors.push({ text: 'Por favor ingrese el nombre del alumno' });
  }

  if (!apellido) {
    errors.push({ text: 'Por favor ingrese el apellido del alumno' });
  }

  if (!edad) {
    errors.push({ text: 'Por favor ingresa la edad del alumno' });
  }

  if (!carrera) {
    errors.push({ text: 'Por favor seleccione una carrera' });
  }

  if (errors.length > 0) {
    const carreras = await Carrera.find().lean();
    res.render('alumnos/add', { errors, nombre, apellido, carrera, carreras });
  } else {
    try {
      const newAlumno = new Alumno({ nombre, apellido, edad, carrera });
      await newAlumno.save();
      req.flash('success_msg', 'Alumno agregado exitosamente');
      res.redirect('/alumnos');
    } catch (error) {
      console.log(error);
    }
  }
});

// Ruta para mostrar todos los alumnos
router.get('/alumnos', async (req, res) => {
  try {
    const alumnos = await Alumno.find().populate('carrera').lean();
    res.render('alumnos/index', { alumnos });
  } catch (error) {
    console.log(error);
  }
});

// Ruta para mostrar el formulario de editar alumno
router.get('/alumnos/edit/:id', async (req, res) => {
  try {
    const carreras = await Carrera.find().lean();
    const alumno = await Alumno.findById(req.params.id).populate('carrera').lean();
    res.render('alumnos/edit', { alumno, carreras });
  } catch (error) {
    console.log(error);
  }
});

// Ruta para actualizar un alumno
router.put('/alumnos/:id', async (req, res) => {
  const { nombre, apellido, edad, carrera, estatus } = req.body;
  try {
    const alumno = await Alumno.findByIdAndUpdate(req.params.id, { nombre, apellido, edad, carrera, estatus });
    req.flash('success_msg', 'Alumno actualizado exitosamente');
    res.redirect('/alumnos');
  } catch (error) {
    console.log(error);
  }
});

// Ruta para eliminar un alumno
router.delete('/alumnos/:id', async (req, res) => {
  try {
    const alumno = await Alumno.findByIdAndDelete(req.params.id);
    if (!alumno) {
      req.flash('error_msg', 'El alumno no existe');
      res.redirect('/alumnos');
      return;
    }
    req.flash('success_msg', 'Alumno eliminado exitosamente');
    res.redirect('/alumnos');
  } catch (error) {
    console.log(error);
  }
});

module.exports = router;
