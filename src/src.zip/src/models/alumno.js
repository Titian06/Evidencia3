const mongoose = require('mongoose');

const alumnoSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true
  },
  apellido: {
    type: String,
    required: true
  },
  edad: {
    type: String,
    required: true
  },
  estatus: {
    type: String,
    enum: ['Inscrito', 'No inscrito'],
    default: 'No inscrito'
  },
  carrera: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Carrera',
    required: true
  }
});

module.exports = mongoose.model('Alumno', alumnoSchema);
