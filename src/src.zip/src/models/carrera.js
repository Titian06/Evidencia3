const mongoose = require('mongoose');

const carreraSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: true
  },
  descripcion: {
    type: String,
    required: true
  },
  departamento: {
    type: String,
    required: true
  }
});

const Carrera = mongoose.model('Carrera', carreraSchema);
module.exports = mongoose.model('Carrera', carreraSchema);
