const passport = require('passport');
const Localstrategy = require('passport-local').Strategy; // Importa la estrategia de autenticación local
const User = require('../models/user'); // Importa el modelo de usuario

// Configura la estrategia de autenticación local
passport.use(new Localstrategy({
    usernameField: 'email' // Define el campo de correo electrónico como nombre de usuario
}, async (email, password, done) => { // Función de verificación de usuario
    const user = await User.findOne({ email: email }); // Busca el usuario por correo electrónico
    if (!user) { // Si no se encuentra el usuario, devuelve un mensaje de error
        return done(null, false, { message: 'Usuario no encontrado' });
    } else {
        const match = await user.matchPassword(password); // Compara las contraseñas
        if (match) { // Si la contraseña coincide, devuelve el usuario
            return done(null, user);
        } else { // Si la contraseña no coincide, devuelve un mensaje de error
            return done(null, false, { message: 'Contraseña incorrecta' });
        }
    }
}));

// Configura la serialización y deserialización del usuario
passport.serializeUser((user, done) => {
    done(null, user.id);
});

passport.deserializeUser(async (id, done) => {
    try {
        const user = await User.findById(id);
        done(null, user);
    } catch (err) {
        done(err);
    }    
});

